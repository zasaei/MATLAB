clc
close all

t = xlsread('timeseris.xlsx');                      
%t(isnan(t))=0;
%i=3;
%j=30;
%for i=3 :size(t,1)
%h=0;
%i=1;
for i=1 : 7062
 %while(i<=58921)
       
     h = size(t);
      k = t(i,7);
        
if  (k>=-8.248577879 && k<3389.58623)
       t(i,5)=0;
       % i=i+1;
       % xlswrite('Good.xlsx',Good); 
        else
  if  (k>50.17176836 && k<101.3505477)
         t(i,5)=1;
        % i=i+1;
     % xlswrite('Moderat.xlsx',Moderat);
        else
  if  (k>6652.827742 && k<10049.26278)
         t(i,5)=2;
        % i=i+1;
      %  xlswrite('Unhealthy for sensitive groups.xlsx',Unhealthygroups); 
        else
  if  (k>150 && k<201)
        t(i,5)=3;
        % i=i+1;
       % xlswrite('Unhealthy.xlsx',Unhealthy);  
         else
  if (k>200 && k<301)
        t(i,5)=4;
         %i=i+1;
       % xlswrite('Very unhealthy.xlsx',Veryunhealthy);
        else
  if (k>300 && k<501)
        t(i,5)=5;
         % i=i+1;
       % xlswrite('Hazardous.xlsx',Hazardous); 
  end 
  end
  end
  end
  end
end

  i=i+1;
 end
   xlswrite('ClassificationAQI1TIMESERIE.xlsx',t); 
    