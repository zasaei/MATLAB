%% Start of Program
clc
clear
close all

%% Data Loading
Data = xlsread('timeseris1NormalizeBASE.xlsx');
X=Data(:,1:end-2);
Y=Data(:,end-1);
DataNum = size(X,1);
InputNum = size(X,2);
OutputNum = size(Y,2);
%% Normalization
%MinX = min(X);
%MaxX = max(X);
%MinY = min(Y);
%MaxY = max(Y);
XN = X;
YN = Y;
%for ii = 2:InputNum
  %  XN(:,ii) = Normalize_Fcn(X(:,ii),MinX(ii),MaxX(ii));
%end
%for ii = 1:OutputNum
  %  YN(:,ii) = Normalize_Fcn(Y(:,ii),MinY(ii),MaxY(ii));
%end
%% Test and Train Data
TrPercent = 80;
TrNum = round(DataNum * TrPercent / 100);
TsNum = DataNum - TrNum;

R = randperm(DataNum);
trIndex = R(1 : TrNum);
tsIndex = R(1+TrNum : end-1);

Xtr = XN(trIndex,:);
Ytr = YN(trIndex,:);

Xts = XN(tsIndex,:);
Yts = YN(tsIndex,:);
%% Network Structure
pr = [0 1];
PR = repmat(pr,InputNum,1);
Network = newff(PR,[5  OutputNum],{'tansig' 'tansig' 'tansig'});
%% Training
Network = train(Network,Xtr',Ytr');
%% Assesment
YtrNet = sim(Network,Xtr')';
YtsNet = sim(Network,Xts')';

MSEtr = mse(YtrNet - Ytr)
MSEts = mse(YtsNet - Yts)

%% Display
figure(1)
plot(Ytr,'-or');
hold on
plot(YtrNet,'-sb');
hold off

figure(2)
plot(Yts,'-or');
hold on
plot(YtsNet,'-sb');
hold off

figure(3)
t = -1:.1:1;
plot(t,t,'b','linewidth',2)
hold on
plot(Ytr,YtrNet,'ok')
hold off

figure(4)
t = -1:.1:1;
plot(t,t,'b','linewidth',2)
hold on
plot(Yts,YtsNet,'ok')
hold off



