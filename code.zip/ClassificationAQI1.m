clc
close all

t = xlsread('22Z.xlsx');                      
%t(isnan(t))=0;
%i=3;
%j=30;
%for i=3 :size(t,1)
%h=0;
%i=1;
for i=1 : 10265
 %while(i<=58921)
       
     h = size(t);
      k = t(i,7);
        
if  (k>=-8.248577879 && k<3389.58623)
       t(i,8)=0;
       % i=i+1;
       % xlswrite('Good.xlsx',Good); 
        else
  if  (k>=3389.58623 && k<6719.424507)
         t(i,8)=1;
        % i=i+1;
     % xlswrite('Moderat.xlsx',Moderat);
        else
  if  (k>=6719.424507 && k<10049.26278)
         t(i,8)=2;
        % i=i+1;
      %  xlswrite('Unhealthy for sensitive groups.xlsx',Unhealthygroups); 
        else
  if  (k>=10049.26278 && k<13379.10106)
        t(i,8)=3;
        % i=i+1;
       % xlswrite('Unhealthy.xlsx',Unhealthy);  
         else
  if (k>=13379.10106 && k<20038.77762)
        t(i,8)=4;
         %i=i+1;
       % xlswrite('Very unhealthy.xlsx',Veryunhealthy);
        else
  if (k>=20038.77762 && k<33358.13072)
        t(i,8)=5;
         % i=i+1;
       % xlswrite('Hazardous.xlsx',Hazardous); 
  end 
  end
  end
  end
  end
end

  i=i+1;
 end
   xlswrite('Classification-GAN4--4.xlsx',t); 
    