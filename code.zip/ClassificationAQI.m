clc
close all

t = xlsread('kh1400.xls');                      
%t(isnan(t))=0;
%i=3;
%j=30;
%for i=3 :size(t,1)
%h=0;
%i=1;
for i=1 : 10274
 %while(i<=58921)
       
     h = size(t);
      k = t(i,8);
        
if  (k>=0 && k<51)
       t(i,9)=0;
       % i=i+1;
       % xlswrite('Good.xlsx',Good); 
        else
  if  (k>50 && k<101)
         t(i,9)=1;
        % i=i+1;
     % xlswrite('Moderat.xlsx',Moderat);
        else
  if  (k>100 && k<151)
         t(i,9)=2;
        % i=i+1;
      %  xlswrite('Unhealthy for sensitive groups.xlsx',Unhealthygroups); 
        else
  if  (k>150 && k<201)
        t(i,9)=3;
        % i=i+1;
       % xlswrite('Unhealthy.xlsx',Unhealthy);  
         else
  if (k>200 && k<301)
        t(i,9)=4;
         %i=i+1;
       % xlswrite('Very unhealthy.xlsx',Veryunhealthy);
        else
  if (k>300)
        t(i,9)=5;
         % i=i+1;
       % xlswrite('Hazardous.xlsx',Hazardous); 
  end 
  end
  end
  end
  end
end

  i=i+1;
 end
   xlswrite('kh1400-GAN.xlsx',t); 
    