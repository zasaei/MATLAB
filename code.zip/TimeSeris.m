clc
clear 
close all
A=xlsread('AANormalize.xlsx');
sumAQ=A(1,31);
sumPM2=A(1,30);
sumPM10=A(1,29);
j=1;
k=1;
N=size(A);
for i=1:N-1
    if  A(i,2)== A(i+1,2)
        k=k+1;
        sumAQ=sumAQ+A(i+1,31);
        sumPM2=sumPM2+A(i+1,30);
        sumPM10=sumPM10+A(i+1,29);
    else
        B(j,1)=A(i,2);
        B(j,2)=sumAQ/k;
        B(j,3)=sumPM2/k;
        B(j,4)=sumPM10/k;
        k=1;
        j=j+1;
        
        sumAQ=A(i+1,31);
        sumPM2=A(i+1,30);
        sumPM10=A(i+1,29);
    end
end
        B(j,1)=A(58919,2);
        B(j,2)=sumAQ/k;
        B(j,3)=sumPM2/k;
        B(j,4)=sumPM10/k;
        k=1;
        t=1;
        
        for i=B(1,1):B(j,1)
            if B(k,1)==i
                C(t,1)=B(k,1);
                C(t,2)=B(k,2);
                C(t,3)=B(k,3);
                C(t,4)=B(k,4);
                t=t+1;
                k=k+1;
            else
                C(t,2:end)=C(t-1,2:end);
                C(t,1)=i;
                t=t+1;
            end
        end
        
          xlswrite('timeseris1NormalizeBASE.xlsx',C);      
       

