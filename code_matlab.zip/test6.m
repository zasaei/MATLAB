clc

a=xlsread('9999.xlsx');
for i=2:417103
    a(i,82)=max(a(i,70:78));
end
xlswrite('full1.xlsx',a);
        