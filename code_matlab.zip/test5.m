a=xlsread('AQI1.xlsx');
b=xlsread('AQI2.xlsx');
c=xlsread('AQI3.xlsx');
d=xlsread('AQI4.xlsx');
 
e=[a;b;c;d];
e=sortrows(e,12);


xlswrite('9999.xlsx',e);
                              