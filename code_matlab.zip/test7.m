c=xlsread('9999.xlsx');
d=xlsread('99999.xlsx');
e=[c;d];
xlswrite('full.xlsx',e);
                 