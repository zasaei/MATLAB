
sum = 0;
con = 0;
t = xlsread('2121hnew.xlsx');
t(isnan(t))=0;
for j=9:81  
 for i=1 : 93819
    if t(i,j)~=0 
        
    sum = sum + t(i,j);
    con = con + 1;
    end
  end
    m = sum / con;
    for i=1 : 93819
        if t(i,j)== 0 
            t(i,j)= m;
        end
    end 
end 
   xlswrite('2121hnew1.xlsx',t); 
    