clear all
a=xlsread('2121h.xlsx');
[h1 h2]=size(a);
for i=1:93818                                                                                                                                                                                                              
    if a(i,1)~=99320

        if a(i,12)==a(i+1,12)
           a(i+1,70:81)=a(i,1:12);
           a(i,:)=[];
                               
        else
            a(i,70:81)=a(i,1:12);
            a(i,1:12)=0;
        end;
    end;
end;
xlswrite('2121hnew.xlsx',a);