a=xlsread('21.xlsx');
b=xlsread('21h.xlsx');
[h1 h2]=size(a);
[t1 t2]=size(b);
c=zeros(h1,t2-h2);
a=cat(2,a,c);
c=cat(1,a,b);
c=sortrows(c,12);
xlswrite('2121h.xlsx',c);
