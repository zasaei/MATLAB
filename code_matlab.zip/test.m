clc
h=1;
h1=1;
h2=1;
h3=1;
for i=0:77
    i
    k=num2str(i);
    a=strcat(k,'.xls');
    tt=xlsread(a);
    ll=size(tt);
    for j=1:ll(1)
        if tt(j,1)==40754
            goal(h,1:69)=tt(j,1:69);
            h=h+1
        end;
        if tt(j,1)==99320
            goal1(h1,1:69)=tt(j,1:69);
            h1=h1+1
        end;
        if tt(j,1)==40751
            goal2(h2,1:69)=tt(j,1:69);
            h2=h2+1
        end;
        if tt(j,1)==99331
            goal3(h3,1:69)=tt(j,1:69);
            h3=h3+1
        end;
    end
end
xlswrite('mehrabad.xlsx',goal);
xlswrite('chitgar.xlsx',goal1);
xlswrite('shemiran.xlsx',goal2);
xlswrite('geophisic.xlsx',goal3);