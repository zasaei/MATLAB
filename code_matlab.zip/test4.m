
t=xlsread('9999.xlsx');
for j=9:81
    x=min(t(:,j));
    y=max(t(:,j));
  for  i=1 : 417102
  z=t(i,j);
  if (y-x)~=0 
  h=((0.9*(z-x))/(y-x))+0.1;
  else
      h=t(i,j);
  end
  t(i,j)=h;
  end 
end
xlswrite('full2.xlsx',t);
  
  